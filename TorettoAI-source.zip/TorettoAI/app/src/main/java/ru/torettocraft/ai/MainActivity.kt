package ru.torettocraft.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("toretto_ai", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFB6D0FF), background = Color(0xFF101114), surface = Color(0xFF191A1F)
            )) {
                TorettoChat(
                    initialLocalEndpoint = prefs.getString("local_endpoint", "http://192.168.1.10:11434/v1/chat/completions") ?: "http://192.168.1.10:11434/v1/chat/completions",
                    initialLocalModel = prefs.getString("local_model", "qwen2.5:7b") ?: "qwen2.5:7b",
                    initialCloudEndpoint = prefs.getString("cloud_endpoint", "https://api.openai.com/v1/chat/completions") ?: "https://api.openai.com/v1/chat/completions",
                    initialCloudModel = prefs.getString("cloud_model", "gpt-4.1-mini") ?: "gpt-4.1-mini",
                    initialApiKey = prefs.getString("api_key", "") ?: "",
                    initialUseCloud = prefs.getBoolean("use_cloud", true),
                    initialSavedMessages = prefs.getString("messages", "[]") ?: "[]",
                    readDocument = { uri ->
                        contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(120_000) }
                            ?: throw IllegalStateException("Не удалось прочитать файл")
                    },
                    saveSettings = { localEndpoint, localModel, cloudEndpoint, cloudModel, key, useCloud ->
                        prefs.edit().putString("local_endpoint", localEndpoint).putString("local_model", localModel)
                            .putString("cloud_endpoint", cloudEndpoint).putString("cloud_model", cloudModel)
                            .putString("api_key", key).putBoolean("use_cloud", useCloud).apply()
                    },
                    saveMessages = { serialized -> prefs.edit().putString("messages", serialized).apply() }
                )
            }
        }
    }
}

data class ChatMessage(val role: String, val text: String)

@Composable
fun TorettoChat(
    initialLocalEndpoint: String, initialLocalModel: String,
    initialCloudEndpoint: String, initialCloudModel: String, initialApiKey: String,
    initialUseCloud: Boolean, initialSavedMessages: String,
    readDocument: (Uri) -> String,
    saveSettings: (String, String, String, String, String, Boolean) -> Unit,
    saveMessages: (String) -> Unit
) {
    var localEndpoint by remember { mutableStateOf(initialLocalEndpoint) }
    var localModel by remember { mutableStateOf(initialLocalModel) }
    var cloudEndpoint by remember { mutableStateOf(initialCloudEndpoint) }
    var cloudModel by remember { mutableStateOf(initialCloudModel) }
    var apiKey by remember { mutableStateOf(initialApiKey) }
    var useCloud by remember { mutableStateOf(initialUseCloud) }
    var draft by remember { mutableStateOf("") }
    var attachment by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Облачный режим включён · настрой API-ключ в ⚙") }
    val messages = remember { mutableStateListOf<ChatMessage>().apply {
        try {
            val arr = JSONArray(initialSavedMessages)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                add(ChatMessage(obj.optString("role", "assistant"), obj.optString("text", "")))
            }
        } catch (_: Exception) { }
        if (isEmpty()) add(ChatMessage("assistant", "Привет! Я Toretto AI. Выбери облачную модель для сложных задач или локальную модель для работы в своей сети. Открой ⚙ для настройки."))
    } }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val name = uri.lastPathSegment ?: "выбранный файл"
                val text = readDocument(uri)
                attachment = "\n\n[Содержимое файла: $name]\n$text"
                status = "Файл добавлен к следующему сообщению (до 120 000 символов)"
            } catch (e: Exception) { status = "Не удалось прочитать файл: ${e.message ?: "ошибка чтения"}" }
        }
    }

    fun persistMessages() {
        val arr = JSONArray()
        messages.takeLast(100).forEach { arr.put(JSONObject().put("role", it.role).put("text", it.text)) }
        saveMessages(arr.toString())
    }
    fun sendMessage() {
        if (busy || (draft.isBlank() && attachment.isBlank())) return
        val prompt = draft.trim() + attachment
        draft = ""; attachment = ""
        messages.add(ChatMessage("user", prompt)); persistMessages()
        busy = true; status = if (useCloud) "Запрос отправлен в облако…" else "Запрос отправлен локальному серверу…"
        scope.launch {
            val endpoint = if (useCloud) cloudEndpoint else localEndpoint
            val model = if (useCloud) cloudModel else localModel
            val key = if (useCloud) apiKey else ""
            val result = if (useCloud && key.isBlank()) {
                Pair("API-ключ не задан. Открой «Настройки API и модели», укажи ключ выбранного API-провайдера и сохрани настройки. Подписка ChatGPT не является API-ключом. Если не хочешь платить за облачные запросы, облачный режим не включай — для локального режима сначала нужно установить совместимую модель и сервер.", "Не задан API-ключ")
            } else {
                askModel(endpoint, model, key, messages.toList())
            }
            messages.add(ChatMessage("assistant", result.first)); persistMessages()
            status = result.second; busy = false
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF101114)).padding(12.dp)) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("TORETTO AI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Личный помощник · гибридный режим", color = Color.LightGray, fontSize = 12.sp)
                }
                TextButton(onClick = {
                    messages.clear()
                    messages.add(ChatMessage("assistant", "История очищена. Чем займёмся?"))
                    persistMessages()
                    status = "История диалога очищена"
                }) { Text("Очистить") }
            }
            Button(
                onClick = { showSettings = !showSettings },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            ) { Text(if (showSettings) "Закрыть настройки" else "⚙ Настройки API и модели") }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = useCloud, onClick = { useCloud = true; status = "Облачный режим: лучше для сложных задач" }, label = { Text("Облако · качество") })
            FilterChip(selected = !useCloud, onClick = { useCloud = false; status = "Локальный режим: требуется доступный сервер в сети" }, label = { Text("Локально · приватность") })
        }
        if (showSettings) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202127)), modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ОБЛАЧНЫЙ СЕРВЕР", color = Color(0xFFB6D0FF), fontWeight = FontWeight.Bold)
                    OutlinedTextField(cloudEndpoint, { cloudEndpoint = it }, label = { Text("URL API") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(cloudModel, { cloudModel = it }, label = { Text("Модель") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API-ключ (хранится на устройстве)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Divider(color = Color.DarkGray)
                    Text("ЛОКАЛЬНЫЙ СЕРВЕР", color = Color(0xFFB6D0FF), fontWeight = FontWeight.Bold)
                    OutlinedTextField(localEndpoint, { localEndpoint = it }, label = { Text("URL локального API") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(localModel, { localModel = it }, label = { Text("Локальная модель") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = {
                        saveSettings(localEndpoint.trim(), localModel.trim(), cloudEndpoint.trim(), cloudModel.trim(), apiKey.trim(), useCloud)
                        showSettings = false; status = "Настройки сохранены на устройстве"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить настройки") }
                    Text("Важно: облачные запросы отправляют текст и вложения выбранному провайдеру. Используй API-ключ только доверенного сервиса. Для локального режима нужен совместимый сервер, например Ollama, доступный по Wi‑Fi.", fontSize = 11.sp, color = Color.LightGray)
                }
            }
        }
        Text(status, color = Color(0xFFB9BBC5), fontSize = 12.sp, modifier = Modifier.padding(vertical = 5.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            itemsIndexed(messages) { _, message ->
                val user = message.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (user) Color(0xFF303B51) else Color(0xFF202127), shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 340.dp)) {
                        Text(message.text, color = Color.White, modifier = Modifier.padding(12.dp), fontSize = 15.sp)
                    }
                }
            }
            if (busy) item { Text("Toretto AI думает…", color = Color.LightGray, modifier = Modifier.padding(8.dp)) }
        }
        if (attachment.isNotBlank()) Text("📎 Файл прикреплён", color = Color(0xFFB6D0FF), fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TextButton(onClick = { filePicker.launch(arrayOf("text/*", "application/json")) }) { Text("＋ Файл") }
            BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f).background(Color(0xFF202127), RoundedCornerShape(22.dp)).padding(horizontal = 16.dp, vertical = 14.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp), decorationBox = { inner -> Box { if (draft.isEmpty()) Text("Напиши сообщение…", color = Color.Gray); inner() } })
            Button(enabled = !busy && (draft.isNotBlank() || attachment.isNotBlank()), onClick = { sendMessage() }, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) { Text(if (busy) "…" else "➤") }
        }
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
}

private val http = OkHttpClient.Builder().connectTimeout(25, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).writeTimeout(60, TimeUnit.SECONDS).build()

private suspend fun askModel(endpoint: String, model: String, apiKey: String, messages: List<ChatMessage>): Pair<String, String> = withContext(Dispatchers.IO) {
    try {
        if (endpoint.isBlank()) return@withContext Pair("Укажи URL сервера в настройках.", "Не указан сервер")
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", "Ты Toretto AI — сильный русскоязычный личный помощник. Отвечай по существу, тщательно анализируй, отделяй факты от предположений. Если задача требует проверки или инструментов, честно сообщай ограничения. Не утверждай, что выполнял действия, которых не выполнял."))
        messages.takeLast(30).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject().put("model", model.ifBlank { "gpt-4.1-mini" }).put("messages", arr).put("stream", false).toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val builder = Request.Builder().url(endpoint).post(body)
        if (apiKey.isNotBlank()) builder.header("Authorization", "Bearer $apiKey")
        http.newCall(builder.build()).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) return@withContext Pair("Сервер ответил HTTP ${response.code}. Проверь URL, название модели, API-ключ и лимиты провайдера.\n\n${raw.take(700)}", "Ошибка API · HTTP ${response.code}")
            val content = JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.opt("content")
            val text = when (content) { is String -> content; is JSONArray -> (0 until content.length()).joinToString("\n") { i -> content.optJSONObject(i)?.optString("text", "") ?: "" }; else -> "" }
            Pair(text.takeIf { it.isNotBlank() } ?: "Сервер вернул пустой ответ.", "Ответ получен · $model")
        }
    } catch (e: Exception) {
        Pair("Не удалось подключиться к серверу. Проверь интернет, URL и доступность API.\n\nПодробности: ${e.message ?: e.javaClass.simpleName}", "Нет соединения")
    }
}
